module com.example.bookstore {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires java.net.http;


    opens com.example.bookstore to javafx.fxml;
    exports com.example.bookstore;
}