package com.example.bookstore;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BookModel {
        public String type;
        public String title;
        public List<String> publisher;
        @SerializedName("author_name")
        public List<String> authorName;
        public List<String> subject;

    public BookModel(String type, String title, List<String> publisher, List<String> authorName, List<String> subject) {
        this.type = type;
        this.title = title;
        this.publisher = publisher;
        this.authorName = authorName;
        this.subject = subject;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getPublisher() {
        return publisher;
    }

    public void setPublisher(List<String> publisher) {
        this.publisher = publisher;
    }

    public List<String> getAuthorName() {
        return authorName;
    }

    public void setAuthorName(List<String> authorName) {
        this.authorName = authorName;
    }

    public List<String> getSubject() {
        return subject;
    }

    public void setSubject(List<String> subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return "BookModel{" +
                "type='" + type + '\'' +
                ", title='" + title + '\'' +
                ", publisher=" + publisher +
                ", authorName=" + authorName +
                ", subject=" + subject +
                '}';
    }
}
