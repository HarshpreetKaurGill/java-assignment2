package com.example.bookstore;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.io.IOException;
import java.util.List;


public class BookStoreController {
    @FXML
    public Label searchLabel;
    @FXML
    public VBox mainContainer;
    @FXML
    public Label infoLabel;
    @FXML
    public Label countLabel;
    @FXML
    public Label header;
    @FXML
    public TextField searchTextField;
    @FXML
    public ListView booksListView;
    @FXML
    public Label bookTitle;

    public void initialize() {
        header.getStyleClass().add("header");
        searchLabel.getStyleClass().add("search-label");
        infoLabel.getStyleClass().add("info-label");
        countLabel.getStyleClass().add("count-label");
        mainContainer.getStyleClass().add("main-container");
    }

    public <T> T getBooks(String query, boolean isDetail) {
        try {
            String rem = "&fields=type,title,publisher,author_name,subject";

            if(isDetail){
                rem = "";
            }

            Gson gson = new Gson();
            URI uri = new URI("https://openlibrary.org/search.json?title=" + query.replace(" ", "+") + rem);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(uri)
                    .GET()
                    .build();
            HttpClient httpClient =  HttpClient.newBuilder().build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            String responseJSON =  response.body();

            JsonElement parsedJSON = JsonParser.parseString(responseJSON);

            if (parsedJSON instanceof JsonObject) {
                JsonObject booksAPIResponse = parsedJSON.getAsJsonObject();
                JsonElement docs = booksAPIResponse.get("docs");

                if (docs instanceof JsonArray) {
                    JsonArray books = docs.getAsJsonArray();
                    if (isDetail){
                        return gson.fromJson(books.get(0), new TypeToken<BookDetailModel>() {}.getType());
                    }else{
                        return gson.fromJson(books, new TypeToken<List<BookModel>>() {}.getType());
                    }
                }
            }
        } catch (URISyntaxException | IOException | InterruptedException e) {
            System.err.println("There was an error fetching data, " + e.getMessage());
        }
        return null;
    }

    public void searchBook() {
        String searchText = searchTextField.getText();
        List<BookModel> bookModels = getBooks(searchText, false);
        if (bookModels != null){
            ObservableList<String> observableList = FXCollections.observableArrayList();
            for (BookModel bookModel : bookModels) {
                observableList.add(bookModel.getTitle());
            }

            infoLabel.setVisible(!observableList.isEmpty());
            countLabel.setText("Books found: " + observableList.size());
            booksListView.setItems(observableList);
        }
    }

    public void viewBookDetail() {
        String selectedItem = (String) booksListView.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            BookDetailModel bookDetailModel = getBooks(selectedItem, true);
            Stage stage = (Stage) booksListView.getScene().getWindow();
            Parent root;
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("bookdetail-view.fxml"));
                root = loader.load();
                BookDetailController controller = loader.getController();
                controller.setHeader(bookDetailModel.getTitle());
                controller.setRating(bookDetailModel.getRatingsAverage());

                if (bookDetailModel.getAuthorName() != null) {
                    StringBuilder author = new StringBuilder();
                    for (String authorName: bookDetailModel.getAuthorName()){
                    author.append(authorName).append(" | ");
                    }
                    controller.setAuthor(author.toString());
                }

                if (bookDetailModel.getPublisher() != null) {
                    StringBuilder publisher = new StringBuilder();
                    int appended = 0;
                    for (String publisherName: bookDetailModel.getPublisher()){
                        if (appended < 11){
                            publisher.append(publisherName).append(" | ");
                        }
                        appended += 1;
                    }
                    controller.setPublisher(publisher.toString());
                }

                if (bookDetailModel.getPublishDate() != null){
                    controller.setPublishedDate(bookDetailModel.getPublishDate().get(0));
                }

                if (bookDetailModel.getEditionKey() != null) {
                    controller.setImage(bookDetailModel.getEditionKey().get(0));
                }

                if (bookDetailModel.getFirstSentence() != null) {
                    controller.setFirstSentence(bookDetailModel.getFirstSentence().get(0));
                }

            } catch (IOException e) {
                throw new RuntimeException(e);
            }

           if (root != null){
               Scene scene = new Scene(root, 600, 500);
               scene.getStylesheets().add(getClass().getResource("bookstore-styles.css").toExternalForm());
               stage.setTitle("Book Detail");
               stage.setScene(scene);
               stage.show();
           }

        }
    }
}
