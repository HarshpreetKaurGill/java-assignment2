package com.example.bookstore;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BookDetailModel {
    public String key;
    public String type;
    public List<String> seed;
    public String title;
    public String titleSuggest;
    public String titleSort;
    public int editionCount;
    @SerializedName("edition_key")
    public List<String> editionKey;
    @SerializedName("publish_date")
    public List<String> publishDate;
    public List<Integer> publishYear;
    public int firstPublishYear;
    public List<String> isbn;
    public long lastModifiedI;
    public int ebookCountI;
    public String ebookAccess;
    public boolean hasFulltext;
    public int ratingsCount1;
    public int ratingsCount2;
    public int ratingsCount3;
    public int ratingsCount4;
    public int ratingsCount5;
    public double ratingsAverage;
    public double ratingsSortable;
    public int ratingsCount;
    public int wantToReadCount;
    public int currentlyReadingCount;
    public int alreadyReadCount;
    public List<String> publisher;
    public List<String> language;
    public List<String> authorKey;
    @SerializedName("author_name")
    public List<String> authorName;
    public List<String> publisherFacet;
    @SerializedName("first_sentence")
    public List<String> firstSentence;
    public long version;
    @SerializedName("author_facet")
    public List<String> authorFacet;

    public BookDetailModel(String key, String type, List<String> seed, String title, String titleSuggest, String titleSort,
                           int editionCount, List<String> editionKey, List<String> publishDate, List<Integer> publishYear,
                           int firstPublishYear, List<String> isbn, long lastModifiedI, int ebookCountI, String ebookAccess,
                           boolean hasFulltext, int ratingsCount1, int ratingsCount2, int ratingsCount3,
                           int ratingsCount4, int ratingsCount5, double ratingsAverage, double ratingsSortable, int ratingsCount,
                           int wantToReadCount, int currentlyReadingCount, int alreadyReadCount,
                           List<String> publisher, List<String> language, List<String> authorKey, List<String> authorName,
                           List<String> publisherFacet, long version, List<String> authorFacet, List<String> firstSentence) {
        this.key = key;
        this.type = type;
        this.seed = seed;
        this.title = title;
        this.titleSuggest = titleSuggest;
        this.titleSort = titleSort;
        this.editionCount = editionCount;
        this.editionKey = editionKey;
        this.publishDate = publishDate;
        this.publishYear = publishYear;
        this.firstPublishYear = firstPublishYear;
        this.isbn = isbn;
        this.lastModifiedI = lastModifiedI;
        this.ebookCountI = ebookCountI;
        this.ebookAccess = ebookAccess;
        this.hasFulltext = hasFulltext;
        this.ratingsCount1 = ratingsCount1;
        this.ratingsCount2 = ratingsCount2;
        this.ratingsCount3 = ratingsCount3;
        this.ratingsCount4 = ratingsCount4;
        this.ratingsCount5 = ratingsCount5;
        this.ratingsAverage = ratingsAverage;
        this.ratingsSortable = ratingsSortable;
        this.ratingsCount = ratingsCount;
        this.wantToReadCount = wantToReadCount;
        this.currentlyReadingCount = currentlyReadingCount;
        this.alreadyReadCount = alreadyReadCount;
        this.publisher = publisher;
        this.language = language;
        this.authorKey = authorKey;
        this.authorName = authorName;
        this.publisherFacet = publisherFacet;
        this.version = version;
        this.firstSentence = firstSentence;
        this.authorFacet = authorFacet;
    }


    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getSeed() {
        return seed;
    }

    public void setSeed(List<String> seed) {
        this.seed = seed;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitleSuggest() {
        return titleSuggest;
    }

    public void setTitleSuggest(String titleSuggest) {
        this.titleSuggest = titleSuggest;
    }

    public String getTitleSort() {
        return titleSort;
    }

    public void setTitleSort(String titleSort) {
        this.titleSort = titleSort;
    }

    public int getEditionCount() {
        return editionCount;
    }

    public void setEditionCount(int editionCount) {
        this.editionCount = editionCount;
    }

    public List<String> getEditionKey() {
        return editionKey;
    }

    public void setEditionKey(List<String> editionKey) {
        this.editionKey = editionKey;
    }

    public List<String> getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(List<String> publishDate) {
        this.publishDate = publishDate;
    }

    public List<String> getFirstSentence(){
        return this.firstSentence;
    }

    public void setFirstSentence(List<String> firstSentence){
        this.firstSentence = firstSentence;
    }

    public List<Integer> getPublishYear() {
        return publishYear;
    }

    public void setPublishYear(List<Integer> publishYear) {
        this.publishYear = publishYear;
    }

    public int getFirstPublishYear() {
        return firstPublishYear;
    }

    public void setFirstPublishYear(int firstPublishYear) {
        this.firstPublishYear = firstPublishYear;
    }

    public List<String> getIsbn() {
        return isbn;
    }

    public void setIsbn(List<String> isbn) {
        this.isbn = isbn;
    }

    public long getLastModifiedI() {
        return lastModifiedI;
    }

    public void setLastModifiedI(long lastModifiedI) {
        this.lastModifiedI = lastModifiedI;
    }

    public int getEbookCountI() {
        return ebookCountI;
    }

    public void setEbookCountI(int ebookCountI) {
        this.ebookCountI = ebookCountI;
    }

    public String getEbookAccess() {
        return ebookAccess;
    }

    public void setEbookAccess(String ebookAccess) {
        this.ebookAccess = ebookAccess;
    }

    public boolean isHasFulltext() {
        return hasFulltext;
    }

    public void setHasFulltext(boolean hasFulltext) {
        this.hasFulltext = hasFulltext;
    }

    public int getRatingsCount1() {
        return ratingsCount1;
    }

    public void setRatingsCount1(int ratingsCount1) {
        this.ratingsCount1 = ratingsCount1;
    }

    public int getRatingsCount2() {
        return ratingsCount2;
    }

    public void setRatingsCount2(int ratingsCount2) {
        this.ratingsCount2 = ratingsCount2;
    }

    public int getRatingsCount3() {
        return ratingsCount3;
    }

    public void setRatingsCount3(int ratingsCount3) {
        this.ratingsCount3 = ratingsCount3;
    }

    public int getRatingsCount4() {
        return ratingsCount4;
    }

    public void setRatingsCount4(int ratingsCount4) {
        this.ratingsCount4 = ratingsCount4;
    }

    public int getRatingsCount5() {
        return ratingsCount5;
    }

    public void setRatingsCount5(int ratingsCount5) {
        this.ratingsCount5 = ratingsCount5;
    }

    public double getRatingsAverage() {
        return ratingsAverage;
    }

    public void setRatingsAverage(double ratingsAverage) {
        this.ratingsAverage = ratingsAverage;
    }

    public double getRatingsSortable() {
        return ratingsSortable;
    }

    public void setRatingsSortable(double ratingsSortable) {
        this.ratingsSortable = ratingsSortable;
    }

    public int getRatingsCount() {
        return ratingsCount;
    }

    public void setRatingsCount(int ratingsCount) {
        this.ratingsCount = ratingsCount;
    }

    public int getWantToReadCount() {
        return wantToReadCount;
    }

    public void setWantToReadCount(int wantToReadCount) {
        this.wantToReadCount = wantToReadCount;
    }

    public int getCurrentlyReadingCount() {
        return currentlyReadingCount;
    }

    public void setCurrentlyReadingCount(int currentlyReadingCount) {
        this.currentlyReadingCount = currentlyReadingCount;
    }

    public int getAlreadyReadCount() {
        return alreadyReadCount;
    }

    public void setAlreadyReadCount(int alreadyReadCount) {
        this.alreadyReadCount = alreadyReadCount;
    }

    public List<String> getPublisher() {
        return publisher;
    }

    public void setPublisher(List<String> publisher) {
        this.publisher = publisher;
    }

    public List<String> getLanguage() {
        return language;
    }

    public void setLanguage(List<String> language) {
        this.language = language;
    }

    public List<String> getAuthorKey() {
        return authorKey;
    }

    public void setAuthorKey(List<String> authorKey) {
        this.authorKey = authorKey;
    }

    public List<String> getAuthorName() {
        return authorName;
    }

    public void setAuthorName(List<String> authorName) {
        this.authorName = authorName;
    }

    public List<String> getPublisherFacet() {
        return publisherFacet;
    }

    public void setPublisherFacet(List<String> publisherFacet) {
        this.publisherFacet = publisherFacet;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public List<String> getAuthorFacet() {
        return authorFacet;
    }

    public void setAuthorFacet(List<String> authorFacet) {
        this.authorFacet = authorFacet;
    }

}
