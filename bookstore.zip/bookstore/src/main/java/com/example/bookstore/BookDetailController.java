package com.example.bookstore;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class BookDetailController {
    @FXML
    public VBox mainContainer;
    @FXML
    public Label author;
    @FXML
    public Label authorKey;
    @FXML
    public Label ratingKey;
    @FXML
    public Label rating;
    @FXML
    public Label publisherKey;
    @FXML
    public Label publisher;
    @FXML
    public Label publishedDateKey;
    @FXML
    public Label publishedDate;
    public ImageView bookImageView;
    public Label firstSentenceKey;
    public Label firstSentence;
    @FXML
    private Label header;

    public void initialize() {
        header.getStyleClass().add("header");
        authorKey.getStyleClass().add("prop-key");
        publisherKey.getStyleClass().add("prop-key");
        ratingKey.getStyleClass().add("prop-key");
        publishedDateKey.getStyleClass().add("prop-key");
        firstSentenceKey.getStyleClass().add("prop-key");
        author.getStyleClass().add("value-key");
        publisher.getStyleClass().add("value-key");
        rating.getStyleClass().add("value-key");
        firstSentence.getStyleClass().add("value-key");
        publishedDate.getStyleClass().add("value-key");
        bookImageView.getStyleClass().add("book-image-view");
        mainContainer.getStyleClass().add("main-container");
    }

    public void setHeader(String title) {
        header.setText(title);
    }

    public void setAuthor(String authorName) {
        author.setText(authorName);
    }

    public void setRating(double ratingV) {
        rating.setText(String.valueOf(ratingV));
    }

    public void setPublisher(String publisherName) {
        publisher.setText(publisherName);
    }

    public void setPublishedDate(String publishedDateV) {
        publishedDate.setText(publishedDateV);
    }

    public void setImage(String bookID) {
        Image image = new Image("https://covers.openlibrary.org/b/olid/" + bookID + "-L.jpg", true);
        bookImageView.setImage(image);
    }

    public void setFirstSentence(String sentence){
        firstSentence.setText(sentence);
    }

    public void goBack() {
        Stage stage = (Stage) mainContainer.getScene().getWindow();
        Parent root;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("bookstore-view.fxml"));
            root = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        if (root != null){
            Scene scene = new Scene(root, 600, 500);
            scene.getStylesheets().add(getClass().getResource("bookstore-styles.css").toExternalForm());
            stage.setTitle("Book Store");
            stage.setScene(scene);
            stage.show();
        }
    }
}